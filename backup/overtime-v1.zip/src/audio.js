// All sound is synthesized with WebAudio: no assets.

const BPM = 132;
const STEP = 60 / BPM / 4; // one 16th note
// Fmaj7 Em7 Dm7 Cmaj7: smooth enough for an elevator, and its roots chug fine as power chords.
const CHORDS = [[53, 57, 60, 64], [52, 55, 59, 62], [50, 53, 57, 60], [48, 52, 55, 59]];
const MELODY = [0, -1, 2, -1, 1, -1, 3, -1, 2, -1, -1, -1, 0, -1, -1, -1]; // chord-tone index per 16th
const hz = (m) => 440 * 2 ** ((m - 69) / 12);

const VOICE = { intern: ['square', 260], manager: ['sawtooth', 190], brute: ['sawtooth', 70], printer: ['square', 620] };

const SOUNDS = {
  shotgun(a, t, o) { a.noise(t, 0.35, 1, o, 'lowpass', 3500, 200); a.osc('sine', 120, 40, t, 0.22, 1, o); },
  pump(a, t, o) { a.noise(t, 0.05, 0.5, o, 'bandpass', 1800, 1800, 3); a.noise(t + 0.13, 0.07, 0.6, o, 'bandpass', 1100, 1100, 3); a.osc('square', 90, 60, t + 0.13, 0.05, 0.2, o); },
  dry(a, t, o) { a.noise(t, 0.04, 0.3, o, 'bandpass', 2500, 2500, 4); },
  axe(a, t, o) { a.noise(t, 0.2, 0.35, o, 'bandpass', 400, 2200, 2); },
  axehit(a, t, o) { a.osc('square', 150, 50, t, 0.12, 0.5, o); a.noise(t, 0.12, 0.7, o, 'lowpass', 1800, 300); },
  launcher(a, t, o) { a.osc('sine', 200, 50, t, 0.25, 0.9, o); a.noise(t, 0.15, 0.5, o, 'lowpass', 1400, 300); },
  explode(a, t, o) { a.noise(t, 1, 1.2, o, 'lowpass', 1800, 60); a.osc('sine', 80, 30, t, 0.6, 1, o); },
  pistol(a, t, o) { a.noise(t, 0.12, 0.6, o, 'highpass', 1500, 700); a.osc('square', 320, 80, t, 0.05, 0.25, o); },
  stapler(a, t, o) { a.noise(t, 0.3, 0.4, o, 'bandpass', 500, 2600, 4); },
  ink(a, t, o) { a.noise(t, 0.4, 0.6, o, 'lowpass', 900, 150); a.osc('sine', 220, 70, t, 0.25, 0.4, o); },
  splat(a, t, o) { a.noise(t, 0.15, 0.4, o, 'lowpass', 1200, 200); },
  punch(a, t, o) { a.osc('sine', 100, 40, t, 0.2, 1, o); a.noise(t, 0.15, 0.8, o, 'lowpass', 1000, 100); },
  gib(a, t, o) { a.noise(t, 0.4, 0.9, o, 'lowpass', 1500, 120); a.noise(t + 0.08, 0.2, 0.5, o, 'bandpass', 600, 300, 2); },
  hurt(a, t, o) { a.osc('sawtooth', 170, 90, t, 0.22, 0.45, o); },
  death(a, t, o) { a.osc('sawtooth', 220, 40, t, 1.4, 0.6, o); a.noise(t, 0.6, 0.4, o, 'lowpass', 800, 100); },
  pickup(a, t, o) { a.osc('square', 660, 660, t, 0.06, 0.15, o); a.osc('square', 990, 990, t + 0.06, 0.09, 0.15, o); },
  weapon(a, t, o) { [440, 554, 659, 880].forEach((f, i) => a.osc('square', f, f, t + i * 0.06, 0.12, 0.15, o)); },
  key(a, t, o) { a.osc('sine', 880, 880, t, 0.5, 0.35, o); a.osc('sine', 1320, 1320, t + 0.12, 0.6, 0.3, o); },
  secret(a, t, o) { [523, 659, 784, 1047, 1319].forEach((f, i) => a.osc('triangle', f, f, t + i * 0.08, 0.3, 0.3, o)); },
  door(a, t, o) { a.noise(t, 0.6, 0.35, o, 'lowpass', 500, 150); a.osc('sine', 60, 50, t, 0.6, 0.25, o); },
  locked(a, t, o) { a.osc('square', 120, 120, t, 0.12, 0.25, o); a.osc('square', 100, 100, t + 0.15, 0.15, 0.25, o); },
  lift(a, t, o) { a.osc('sawtooth', 55, 70, t, 6, 0.15, o); },
  spawn(a, t, o) { a.osc('sawtooth', 100, 900, t, 0.5, 0.25, o); a.noise(t, 0.5, 0.4, o, 'bandpass', 300, 3000, 2); },
  rankup(a, t, o) { [0, 4, 7, 12, 16].forEach((n, i) => a.osc('sawtooth', hz(64 + n), hz(64 + n), t + i * 0.05, 0.25, 0.18, o)); },
  rankdown(a, t, o) { a.osc('sawtooth', 300, 120, t, 0.35, 0.15, o); },
};

// Per-enemy sight sound, attack tell, pain and death: same voice, different gesture.
function enemySound(a, kind, type, t, o) {
  const [w, f] = VOICE[type];
  if (kind === 'sight') {
    if (type === 'intern') { a.osc(w, f, f * 0.7, t, 0.5, 0.25, o); a.osc(w, f * 0.75, f * 0.6, t + 0.35, 0.5, 0.2, o); }
    else if (type === 'manager') { a.osc(w, f, f, t, 0.15, 0.3, o); a.osc(w, f * 1.25, f * 0.9, t + 0.18, 0.35, 0.3, o); }
    else if (type === 'brute') { a.osc(w, f, f * 0.8, t, 1, 0.6, o); a.noise(t, 1, 0.3, o, 'lowpass', 400, 200); }
    else { [1, 1.5, 1, 2].forEach((m, i) => a.osc(w, f * m, f * m, t + i * 0.09, 0.08, 0.15, o)); a.noise(t, 0.4, 0.2, o, 'bandpass', 3000, 3000, 3); }
  } else if (kind === 'tell') {
    if (type === 'intern') { a.noise(t, 0.03, 0.4, o, 'bandpass', 3000, 3000, 5); a.noise(t + 0.12, 0.03, 0.4, o, 'bandpass', 3500, 3500, 5); }
    else if (type === 'manager') a.noise(t, 0.45, 0.35, o, 'bandpass', 300, 2000, 3);
    else if (type === 'brute') { a.osc(w, 120, 60, t, 0.6, 0.6, o); a.noise(t, 0.6, 0.4, o, 'lowpass', 600, 200); }
    else a.osc(w, 200, 900, t, 0.5, 0.2, o);
  } else if (kind === 'pain') a.osc(w, f * 1.3, f * 0.8, t, 0.15, 0.3, o);
  else { a.osc(w, f, f * 0.3, t, 0.6, 0.35, o); a.noise(t, 0.3, 0.3, o, 'lowpass', 1200, 200); }
}

export class Audio {
  ctx = null;
  listener = { x: 0, y: 0, z: 0, yaw: 0 };
  rank = 0;

  init() {
    if (this.ctx) return void this.ctx.resume();
    const ctx = (this.ctx = new AudioContext());
    this.master = this.gain(0.7, ctx.destination);
    this.sfx = this.gain(1, this.master);
    this.music = this.gain(0.3, this.master);
    const len = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    // Music layers 0..5, one per rank: muzak, bass, light drums, guitar, heavy drums, full metal.
    this.layers = Array.from({ length: 6 }, (_, i) => this.gain(i === 0 ? 1 : 0, this.music));
    this.guitar = [3, 5].map((i) => {
      const shaper = ctx.createWaveShaper(), lp = ctx.createBiquadFilter();
      const curve = new Float32Array(1024);
      for (let k = 0; k < 1024; k++) { const x = (k / 512) - 1; curve[k] = ((3 + 60) * x * 20 * Math.PI / 180) / (Math.PI + 60 * Math.abs(x)); }
      shaper.curve = curve;
      lp.frequency.value = 2800;
      const input = ctx.createGain();
      input.connect(shaper).connect(lp).connect(this.layers[i]);
      return input;
    });
    this.step = 0;
    this.next = ctx.currentTime + 0.1;
    setInterval(() => this.tick(), 25);
  }

  suspend() { this.ctx?.suspend(); }
  resume() { this.ctx?.resume(); }

  gain(v, to) {
    const g = this.ctx.createGain();
    g.gain.value = v;
    g.connect(to);
    return g;
  }

  osc(type, f0, f1, t, dur, vol, out) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(out);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  noise(t, dur, vol, out, type = 'lowpass', f0 = 2000, f1 = f0, q = 1) {
    const c = this.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf;
    f.type = type;
    f.Q.value = q;
    f.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(out);
    s.start(t, Math.random() * 0.9);
    s.stop(t + dur + 0.02);
  }

  // pos: world position for distance falloff + stereo pan, or null for the player's own sounds.
  play(name, pos = null, delay = 0) {
    if (!this.ctx || this.ctx.state !== 'running') return;
    const c = this.ctx, t = c.currentTime + delay, L = this.listener;
    let out = this.sfx;
    if (pos) {
      const dx = pos.x - L.x, dy = pos.y - L.y, dz = pos.z - L.z, dist = Math.hypot(dx, dy, dz);
      if (dist > 70) return;
      const g = c.createGain(), pan = c.createStereoPanner();
      g.gain.value = 1 / (1 + dist * 0.12);
      pan.pan.value = dist > 0.1 ? Math.max(-1, Math.min(1, (dx * Math.cos(L.yaw) - dz * Math.sin(L.yaw)) / dist)) * 0.8 : 0;
      g.connect(pan).connect(this.sfx);
      out = g;
    }
    const [kind, type] = name.split('_');
    if (type) enemySound(this, kind, type, t, out);
    else SOUNDS[name](this, t, out);
  }

  setRank(r) {
    this.rank = r;
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    this.layers.forEach((g, i) => g.gain.setTargetAtTime(i === 0 ? (r >= 5 ? 0.3 : 1) : i <= r ? 1 : 0, now, 0.4));
  }

  tick() {
    const c = this.ctx;
    if (c.state !== 'running') return;
    if (this.next < c.currentTime) this.next = c.currentTime + 0.05; // tab was throttled: skip, don't burst
    while (this.next < c.currentTime + 0.15) {
      this.beat(this.step++, this.next);
      this.next += STEP;
    }
  }

  beat(step, t) {
    const bar = Math.floor(step / 16) % 4, s = step % 16, ch = CHORDS[bar], L = this.layers, r = this.rank;
    const kick = (vol, out) => this.osc('sine', 150, 40, t, 0.15, vol, out);
    const chug = (out, dur) => { this.osc('sawtooth', hz(ch[0] - 12), hz(ch[0] - 12), t, dur, 0.12, out); this.osc('sawtooth', hz(ch[0] - 5), hz(ch[0] - 5), t, dur, 0.1, out); };
    // 0: elevator muzak
    if (s === 0 || s === 10) for (const n of ch) this.osc('sine', hz(n), hz(n), t, STEP * 6, 0.05, L[0]);
    if (MELODY[s] >= 0) this.osc('triangle', hz(ch[MELODY[s]] + 12), hz(ch[MELODY[s]] + 12), t, STEP * 3, 0.07, L[0]);
    // 1: bass
    if (r >= 1 && s % 4 === 0) this.osc('triangle', hz(ch[0] - 24), hz(ch[0] - 24), t, STEP * 3, 0.3, L[1]);
    // 2: light drums
    if (r >= 2) {
      if (s % 8 === 0) kick(0.6, L[2]);
      if (s % 2 === 0) this.noise(t, 0.04, 0.08, L[2], 'highpass', 7000);
    }
    // 3: distorted palm-muted guitar
    if (r >= 3 && s % 2 === 0) chug(this.guitar[0], STEP * 1.5);
    // 4: snare, crash, busier kick
    if (r >= 4) {
      if (s === 4 || s === 12) { this.noise(t, 0.15, 0.5, L[4], 'bandpass', 1800, 1800, 0.8); this.osc('triangle', 190, 140, t, 0.1, 0.3, L[4]); }
      if (s === 10) kick(0.6, L[4]);
      if (s === 0 && bar === 0) this.noise(t, 1.2, 0.25, L[4], 'highpass', 5000);
    }
    // 5: C-SUITE: double kick and 16th chugs
    if (r >= 5) {
      kick(0.45, L[5]);
      if (s % 2 === 1) chug(this.guitar[1], STEP);
    }
  }
}
