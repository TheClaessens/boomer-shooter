import * as THREE from 'three';

const cube = new THREE.BoxGeometry(1, 1, 1);
const sphere = new THREE.IcosahedronGeometry(1, 1);
const MAX = 500;

// Particles, gibs, tracers and explosion balls. Everything is a short-lived mesh.
export class FX {
  constructor(scene) {
    this.scene = scene;
    this.items = [];
    this.mats = new Map();
  }

  mat(color) {
    if (!this.mats.has(color)) this.mats.set(color, new THREE.MeshBasicMaterial({ color }));
    return this.mats.get(color);
  }

  add(mesh, vel, life, gravity, bounce = false, grow = 0) {
    this.scene.add(mesh);
    this.items.push({ mesh, vel, life, max: life, gravity, bounce, grow, size: mesh.scale.x, rest: false });
    if (this.items.length > MAX) this.remove(0);
  }

  remove(i) {
    const it = this.items[i];
    this.scene.remove(it.mesh);
    if (it.own) it.mesh.material.dispose();
    this.items.splice(i, 1);
  }

  burst(pos, color, n, speed = 4, size = 0.08, life = 0.5) {
    for (let i = 0; i < n; i++) {
      const m = new THREE.Mesh(cube, this.mat(color));
      m.scale.setScalar(size * (0.6 + Math.random() * 0.8));
      m.position.copy(pos);
      const v = new THREE.Vector3(Math.random() - 0.5, Math.random() * 0.8, Math.random() - 0.5).normalize().multiplyScalar(speed * (0.3 + Math.random()));
      this.add(m, v, life * (0.6 + Math.random() * 0.8), 14);
    }
  }

  gibs(pos, colors, n = 14) {
    for (let i = 0; i < n; i++) {
      const m = new THREE.Mesh(cube, this.mat(colors[i % colors.length]));
      m.scale.set(0.12 + Math.random() * 0.25, 0.12 + Math.random() * 0.2, 0.12 + Math.random() * 0.25);
      m.position.copy(pos).add(new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5));
      const v = new THREE.Vector3(Math.random() - 0.5, Math.random() * 0.9 + 0.3, Math.random() - 0.5).normalize().multiplyScalar(5 + Math.random() * 7);
      this.add(m, v, 8, 20, true);
    }
    this.burst(pos, colors[0], 20, 7, 0.12, 0.8);
  }

  explosion(pos, radius, color = 0xff8a20) {
    const m = new THREE.Mesh(sphere, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9 }));
    m.position.copy(pos);
    m.scale.setScalar(0.3);
    this.add(m, new THREE.Vector3(), 0.35, 0, false, radius);
    this.items[this.items.length - 1].own = true;
    this.burst(pos, color, 16, 9, 0.14, 0.5);
    this.burst(pos, 0x404040, 10, 4, 0.2, 0.9);
  }

  tracer(a, b, color = 0xffe080) {
    const g = new THREE.BufferGeometry().setFromPoints([a, b]);
    const line = new THREE.Line(g, this.mat(color));
    this.scene.add(line);
    setTimeout(() => { this.scene.remove(line); g.dispose(); }, 50);
  }

  update(dt, solids) {
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i], m = it.mesh;
      it.life -= dt;
      if (it.life <= 0) { this.remove(i); continue; }
      if (it.grow) {
        const k = 1 - it.life / it.max;
        m.scale.setScalar(0.3 + it.grow * k);
        m.material.opacity = 0.9 * (1 - k);
        continue;
      }
      if (it.rest) continue;
      it.vel.y -= it.gravity * dt;
      const ox = m.position.x, oy = m.position.y, oz = m.position.z;
      m.position.addScaledVector(it.vel, dt);
      m.rotation.x += dt * 6;
      if (!it.bounce) {
        m.scale.setScalar(it.size * Math.min(1, it.life / it.max * 2));
        continue;
      }
      const p = m.position;
      for (const s of solids) {
        if (p.x > s.x0 && p.x < s.x1 && p.y > s.y0 && p.y < s.y1 && p.z > s.z0 && p.z < s.z1) {
          p.set(ox, oy, oz);
          it.vel.multiplyScalar(0.4);
          if (it.vel.y < 0) it.vel.y *= -0.5;
          if (it.vel.lengthSq() < 0.5) it.rest = true;
          break;
        }
      }
    }
  }
}
