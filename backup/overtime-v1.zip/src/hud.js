import { RANKS, rankOf, grade, PAR } from './style.js';

const $ = (id) => document.getElementById(id);
const fmt = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
// Fixed blood splatter spots on the ID photo, revealed as health drops.
const SPLATS = [[9, 14, 3], [27, 20, 2], [15, 31, 3], [24, 9, 2], [7, 25, 2], [30, 30, 3], [18, 22, 2], [12, 8, 2], [28, 14, 2], [20, 36, 3]];

export class Hud {
  constructor() {
    this.last = {};
    this.msgT = 0;
    this.bonusT = 0;
    this.hurtA = 0;
    this.flashA = 0;
    this.face = 'normal';
    this.faceT = 0;
    this.badge = $('badge').getContext('2d');
  }

  set(id, value) {
    if (this.last[id] === value) return;
    this.last[id] = value;
    $(id).textContent = value;
  }

  show(on) { $('hud').hidden = !on; }

  msg(text, dur = 2) {
    $('msg').textContent = text;
    this.msgT = dur;
  }

  bonus(list) {
    if (!list.length) return;
    $('bonus').textContent = list.map((b) => '+' + b).join('  ');
    this.bonusT = 1.4;
  }

  hurt(angle, dmg) {
    this.hurtA = Math.min(0.7, this.hurtA + 0.15 + dmg * 0.015);
    $('dir').style.background = `radial-gradient(circle at ${50 + Math.sin(angle) * 50}% ${50 - Math.cos(angle) * 50}%, rgba(255,0,0,0.85), transparent 45%)`;
    this.face = 'ouch';
    this.faceT = 0.5;
  }

  grin() {
    if (this.face !== 'ouch') { this.face = 'grin'; this.faceT = 0.8; }
  }

  pickupFlash() { this.flashA = Math.max(this.flashA, 0.25); $('flash').style.background = '#ffe080'; }

  rankUp(name) {
    this.flashA = 0.6;
    $('flash').style.background = '#ffd030';
    this.msg(`PROMOTED: ${name}`, 2);
  }

  update(g, dt) {
    const p = g.player, s = g.style, r = rankOf(s);
    this.set('hp', Math.ceil(p.health));
    this.set('ar', Math.floor(p.armor));
    this.set('ammolabel', p.weapon === 'axe' ? 'AXE' : p.weapon === 'shotgun' ? 'SHELLS' : 'TONER');
    this.set('ammo', p.weapon === 'axe' ? '--' : p.weapon === 'shotgun' ? p.ammo.shells : p.ammo.toner);
    const arms = ['axe', 'shotgun', 'launcher'].map((w, i) => `<b class="${w === p.weapon ? 'on' : p.owned[w] ? '' : 'off'}">${i + 1}</b>`).join('');
    if (this.last.arms !== arms) $('arms').innerHTML = this.last.arms = arms;
    $('key').hidden = !p.hasKey;
    this.set('rank', RANKS[r]);
    $('rank').className = 'r' + r;
    $('fill').style.width = `${Math.min(100, s.points - r * 100)}%`;
    this.set('kills', `KILLS ${g.stats.kills}/${g.stats.total}  ${fmt(g.stats.time)}`);

    this.msgT -= dt;
    $('msg').style.opacity = this.msgT > 0 ? 1 : 0;
    this.bonusT -= dt;
    $('bonus').style.opacity = this.bonusT > 0 ? 1 : 0;
    this.hurtA = Math.max(0, this.hurtA - dt * 1.5);
    $('hurt').style.opacity = this.hurtA * 0.6;
    $('dir').style.opacity = this.hurtA * 1.4;
    this.flashA = Math.max(0, this.flashA - dt * 2);
    $('flash').style.opacity = this.flashA;
    this.faceT -= dt;
    if (this.faceT <= 0) this.face = 'normal';
    const face = p.dead ? 'dead' : this.face;
    const key = `${Math.ceil(p.health / 15)}${face}`;
    if (this.last.badge !== key) {
      this.last.badge = key;
      this.drawBadge(p.health, face);
    }
  }

  // The ID-badge photo: Doom's face, but HR-approved. Bloodier as health drops.
  drawBadge(health, face) {
    const c = this.badge;
    c.fillStyle = '#d8e4f0'; c.fillRect(0, 0, 40, 48);
    c.fillStyle = '#2050a0'; c.fillRect(0, 0, 40, 6);
    c.fillStyle = '#7890a8'; c.fillRect(4, 8, 32, 32);
    c.fillStyle = '#3a2a1a'; c.fillRect(10, 11, 20, 6);
    c.fillStyle = '#e0b090'; c.fillRect(11, 15, 18, 20);
    c.fillStyle = '#2a4a8a'; c.fillRect(8, 35, 24, 5);
    c.fillStyle = '#202020';
    if (face === 'dead') {
      for (const x of [14, 23]) { c.fillRect(x, 20, 1, 1); c.fillRect(x + 2, 22, 1, 1); c.fillRect(x + 1, 21, 1, 1); c.fillRect(x + 2, 20, 1, 1); c.fillRect(x, 22, 1, 1); }
    } else {
      const squint = face === 'ouch' || health < 30 ? 1 : 2;
      c.fillRect(14, 21, 3, squint);
      c.fillRect(23, 21, 3, squint);
    }
    if (face === 'ouch' || face === 'dead') c.fillRect(17, 28, 6, 4);
    else if (face === 'grin') { c.fillRect(15, 28, 10, 2); c.fillStyle = '#fff'; c.fillRect(16, 28, 8, 1); }
    else c.fillRect(17, 29, 6, 1);
    c.fillStyle = '#a00';
    const n = Math.round((1 - Math.max(0, health) / 100) * SPLATS.length);
    for (const [x, y, s] of SPLATS.slice(0, n)) { c.fillRect(x, y, s, s); c.fillRect(x + 1, y + s, 1, 2); }
    c.fillStyle = '#203040'; c.fillRect(4, 42, 32, 2); c.fillRect(4, 45, 20, 1);
  }

  screen(kind, g) {
    const el = $('screen');
    el.hidden = !kind;
    this.show(kind !== 'title');
    if (kind === 'title') {
      el.innerHTML = `<h1>OVERTIME</h1>
        <p class="sub">Demons came in through the server room. Your shift isn't over.</p>
        <table class="keys">
          <tr><td>WASD</td><td>move</td><td>MOUSE</td><td>look</td></tr>
          <tr><td>SPACE</td><td>jump</td><td>CLICK</td><td>fire</td></tr>
          <tr><td>1 2 3 / WHEEL</td><td>weapons</td><td>R</td><td>restart</td></tr>
          <tr><td>P</td><td>pixel filter</td><td>ESC</td><td>pause</td></tr>
        </table>
        <p class="blink">CLICK TO CLOCK IN</p>`;
    } else if (kind === 'paused') {
      el.innerHTML = `<h2>COFFEE BREAK</h2><p class="blink">CLICK TO RESUME</p><p class="sub">R restart · P pixel filter</p>`;
    } else if (kind === 'dead') {
      el.innerHTML = `<h2 class="red">YOU'RE FIRED</h2><p class="blink">PRESS R OR CLICK TO REAPPLY</p>`;
    } else if (kind === 'score') {
      const st = g.stats, peak = g.style.peak;
      const gr = grade({ kills: st.kills, total: st.total, secrets: st.secrets, time: st.time, peak });
      el.innerHTML = `<h2>PERFORMANCE REVIEW</h2>
        <table class="review">
          <tr><td>Kills</td><td>${st.kills} / ${st.total} (${Math.round((st.kills / st.total) * 100)}%)</td></tr>
          <tr><td>Secrets</td><td>${st.secrets} / 3</td></tr>
          <tr><td>Time</td><td>${fmt(st.time)} <span class="sub">(par ${fmt(PAR)})</span></td></tr>
          <tr><td>Peak rank</td><td>${RANKS[peak]}</td></tr>
        </table>
        <div class="grade g${gr}">${gr}</div>
        <p class="blink">PRESS R TO REPLAY</p>`;
    }
  }
}
