import * as THREE from 'three';

// The tower. Units are metres, y up, the player starts in the lobby facing north (-z) at the red door.
//
//   server room (-52..-24, -44..-21) ──red corridor──► red door ─► LOBBY (-16..16) ─► elevator ─► CEO floor (y 24)
//        ▲                                                            │
//   cubicle floor (-52..-20, -16..24) ◄───────────────────────────────┘

const T = 0.5; // wall thickness

const LOBBY = { floor: 0x8a8070, wall: 0xd6caa8, ceil: 0xe6e0d0 };
const CUBES = { floor: 0x4a4e52, wall: 0xbcb094, ceil: 0x9c988c };
const SERVER = { floor: 0x2a3038, wall: 0x3c4652, ceil: 0x20262c };
const HELL = { floor: 0x4a3430, wall: 0x6a3a34, ceil: 0x3a2622 };
const CEO = { floor: 0x5a1c1c, wall: 0x4a3830, ceil: 0x2a1a18 };
const VENT = { floor: 0x5a5a5a, wall: 0x7a7a78, ceil: 0x6a6a68 };

// Seeded so the level dresses identically on every restart.
let seed = 1;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

export function buildLevel(scene) {
  seed = 1;
  const solids = [], doors = [], triggers = [], pickups = [], enemies = [], flicker = [];
  const geo = new THREE.BoxGeometry(1, 1, 1);
  const mats = new Map();
  const mat = (color, glow) => {
    const k = color + (glow ? 'g' : '');
    if (!mats.has(k)) mats.set(k, new THREE.MeshLambertMaterial({ color, emissive: glow ? color : 0 }));
    return mats.get(k);
  };

  function box(x0, y0, z0, x1, y1, z1, color, { solid = true, glow = false, material } = {}) {
    const mesh = new THREE.Mesh(geo, material ?? mat(color, glow));
    mesh.scale.set(x1 - x0, y1 - y0, z1 - z0);
    mesh.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
    scene.add(mesh);
    if (solid) solids.push({ x0, y0, z0, x1, y1, z1 });
    return mesh;
  }

  // A wall slab spanning a0..a1 along x (alongX) or z, with door gaps [g0, g1, height].
  function wallRun(alongX, c0, c1, a0, a1, y0, y1, gaps = [], color) {
    const seg = (s0, s1, ya, yb) => (alongX ? box(s0, ya, c0, s1, yb, c1, color) : box(c0, ya, s0, c1, yb, s1, color));
    let cur = a0;
    for (const [g0, g1, h] of [...gaps].sort((a, b) => a[0] - b[0])) {
      if (g0 > cur) seg(cur, g0, y0, y1);
      if (y0 + h < y1) seg(g0, g1, y0 + h, y1);
      cur = g1;
    }
    if (cur < a1) seg(cur, a1, y0, y1);
  }

  // Interior x0..x1, z0..z1, y0..y1; walls sit outside the interior. gaps per side n/s/w/e.
  function room(x0, z0, x1, z1, y0, y1, c, gaps = {}) {
    box(x0 - T, y0 - T, z0 - T, x1 + T, y0, z1 + T, c.floor);
    box(x0 - T, y1, z0 - T, x1 + T, y1 + T, z1 + T, c.ceil);
    wallRun(true, z0 - T, z0, x0 - T, x1 + T, y0, y1, gaps.n, c.wall);
    wallRun(true, z1, z1 + T, x0 - T, x1 + T, y0, y1, gaps.s, c.wall);
    wallRun(false, x0 - T, x0, z0, z1, y0, y1, gaps.w, c.wall);
    wallRun(false, x1, x1 + T, z0, z1, y0, y1, gaps.e, c.wall);
  }

  // Open-ended passage; its ends butt against room wall gaps.
  function hall(x0, z0, x1, z1, y0, h, c, alongX) {
    box(x0, y0 - T, z0, x1, y0, z1, c.floor);
    box(x0, y0 + h, z0, x1, y0 + h + T, z1, c.ceil);
    if (alongX) {
      box(x0, y0, z0 - T, x1, y0 + h, z0, c.wall);
      box(x0, y0, z1, x1, y0 + h, z1 + T, c.wall);
    } else {
      box(x0 - T, y0, z0, x0, y0 + h, z1, c.wall);
      box(x1, y0, z0, x1 + T, y0 + h, z1, c.wall);
    }
  }

  // Doors slide up on touch. key: needs the red keycard and wears its stripe. secret: opens only when bumped.
  function door(x0, y0, z0, x1, y1, z1, color, { key = false, secret = false } = {}) {
    const meshes = [box(x0, y0, z0, x1, y1, z1, color, { solid: false })];
    if (key) {
      const h = y1 - y0, thinX = x1 - x0 < z1 - z0;
      meshes.push(thinX
        ? box(x0 - 0.03, y0 + h * 0.42, z0, x1 + 0.03, y0 + h * 0.58, z1, 0xd01010, { solid: false, glow: true })
        : box(x0, y0 + h * 0.42, z0 - 0.03, x1, y0 + h * 0.58, z1 + 0.03, 0xd01010, { solid: false, glow: true }));
    }
    for (const m of meshes) m.userData.baseY = m.position.y;
    doors.push({ box: { x0, y0, z0, x1, y1, z1 }, base: { x0, y0, z0, x1, y1, z1 }, h: y1 - y0, cx: (x0 + x1) / 2, cz: (z0 + z1) / 2, meshes, open: 0, hold: 0, key, secret });
  }

  function light(x, y, z, color, intensity, dist, flickers = false) {
    const l = new THREE.PointLight(color, intensity, dist, 1);
    l.position.set(x, y, z);
    scene.add(l);
    if (flickers) flicker.push({ light: l, base: intensity });
  }

  const fleshMat = new THREE.MeshLambertMaterial({ color: 0xa02838, emissive: 0x300008, flatShading: true });
  const blob = new THREE.IcosahedronGeometry(1, 0);
  function flesh(x, y, z, s = 1) {
    for (let i = 0; i < 4; i++) {
      const m = new THREE.Mesh(blob, fleshMat);
      m.scale.setScalar(s * (0.3 + rnd() * 0.4));
      m.position.set(x + (rnd() - 0.5) * s, y + (rnd() - 0.5) * s, z + (rnd() - 0.5) * s);
      m.rotation.set(rnd() * 3, rnd() * 3, 0);
      scene.add(m);
    }
  }

  const trig = (x0, y0, z0, x1, y1, z1, kind, arg) => triggers.push({ box: { x0, y0, z0, x1, y1, z1 }, kind, arg, fired: false });
  const pick = (kind, x, y, z) => pickups.push([kind, x, y, z]);
  const mob = (type, x, y, z, group = null) => enemies.push([type, x, y, z, group]);

  // ── LOBBY ATRIUM (hub): tall, bright, CEO's glass office hanging overhead ──────────────
  room(-16, -16, 16, 16, 0, 22, LOBBY, { n: [[-2, 2, 4]], w: [[8, 12, 3.5]], e: [[-2, 2, 4]], s: [[10.5, 12, 2]] });
  box(-3, 0, -16, 3, 0.02, 16, 0x6a2020, { solid: false }); // red carpet runner to the red door
  box(-1.5, 0, -1.5, 1.5, 22, 1.5, 0xb8ae98); // atrium column landmark
  for (const y of [4, 10, 16]) box(-1.8, y, -1.8, 1.8, y + 0.4, 1.8, 0x8a7a5a);
  // Red door frame, visible from the spawn so the keycard hints at it.
  for (const [a, b] of [[-2.4, -2], [2, 2.4]]) box(a, 0, -15.95, b, 4.4, -15.9, 0xd01010, { solid: false, glow: true });
  box(-2.4, 4, -15.95, 2.4, 4.4, -15.9, 0xd01010, { solid: false, glow: true });
  door(-2, 0, -16.5, 2, 4, -16, 0x4a4a50, { key: true });
  // Security desk + emergency axe box by the spawn.
  box(-8, 0, 4, -2, 1.1, 6, 0x6a5038);
  box(-8.2, 1.1, 3.8, -1.8, 1.2, 6.2, 0x3a2a20);
  box(-7, 1.2, 4.2, -6.2, 1.7, 4.5, 0x20ff80, { glow: true, solid: false });
  box(-1, 1.2, 15.75, 1, 2.4, 16, 0xb01010, { solid: false });
  box(-0.8, 1.35, 15.7, 0.8, 2.25, 15.75, 0x101010, { solid: false });
  // Vending machine hiding the air vent (secret 1).
  box(9.5, 0, 13.6, 13, 2.6, 15, 0x2050a0);
  box(9.8, 0.9, 13.55, 12.7, 2.3, 13.6, 0x80c0ff, { solid: false, glow: true });
  hall(10.5, 16.5, 12, 20.5, 0, 2, VENT, false);
  room(9, 21, 13.5, 25, 0, 2.5, VENT, { n: [[10.5, 12, 2]] });
  light(11.25, 2, 23, 0xffaa55, 3, 6);
  trig(9, 0, 21, 13.5, 2.5, 25, 'secret');
  pick('espresso', 11.25, 0.5, 23.5);
  // Rocket-jump ledge high on the east wall (secret 2).
  box(13, 5.5, 6, 16, 6, 14, 0x9a9080);
  trig(13, 6, 6, 16, 9, 14, 'secret');
  pick('kevlar', 14.5, 6.6, 10);
  pick('toner', 14.5, 6.5, 8);
  pick('toner', 14.5, 6.5, 12);
  // The CEO's glass office: a promise, hung high from the first second.
  const glass = new THREE.MeshLambertMaterial({ color: 0x88bbdd, transparent: true, opacity: 0.3, depthWrite: false });
  box(-8, 15, -15, 8, 20, -7, 0, { solid: false, material: glass });
  box(-8, 14.7, -15, 8, 15, -7, 0x3a2a26, { solid: false });
  box(-2, 15, -12, 2, 15.9, -11, 0x4a2a18, { solid: false });
  for (const [x, z] of [[-7.8, -14.8], [7.6, -14.8], [-7.8, -7.2], [7.6, -7.2]]) box(x, 20, z, x + 0.2, 22, z + 0.2, 0x303030, { solid: false });
  light(0, 18, -11, 0xff3020, 8, 12);
  // Plants and benches.
  for (const [x, z] of [[-14, -14], [14, -14], [-14, 14]]) {
    box(x - 0.5, 0, z - 0.5, x + 0.5, 0.8, z + 0.5, 0x6a4a30);
    box(x - 0.7, 0.8, z - 0.7, x + 0.7, 2.2, z + 0.7, 0x2a6a2a, { solid: false });
  }
  box(-14, 0, -4, -12.5, 0.5, 4, 0x5a4030);
  for (const [x, z] of [[-8, -8], [8, 8], [-8, 8], [8, -8]]) {
    box(x - 2, 21.9, z - 2, x + 2, 22, z + 2, 0xffffff, { solid: false, glow: true });
    light(x, 18, z, 0xfff4e0, 16, 40);
  }
  light(0, 5, 11, 0xfff0d0, 8, 20);
  pick('shells', -6, 1.5, 5.7);
  pick('shells', -3.5, 1.5, 5.7);
  pick('coffee', 12, 0.4, 10);
  pick('coffee', -12, 0.4, -12);
  pick('kevlar', 13, 0.5, -4);
  pick('shells', -12, 0.4, 0);
  mob('intern', 6, 0, -8);
  mob('intern', -8, 0, -10);
  mob('intern', 10, 0, 0);
  // Repopulates when you loop back in through the red door.
  mob('manager', 8, 0, -12, 'lobby');
  mob('manager', -10, 0, 8, 'lobby');
  mob('printer', 5, 8, 5, 'lobby');
  mob('printer', -6, 10, -6, 'lobby');
  trig(-3, 0, -16, 3, 4, -12, 'ambush', 'lobby');

  // ── ELEVATOR (red badge) up to the CEO floor ──────────────────────────────────────────
  const SHAFT = 0x3a3436;
  box(15.9, 4.3, -1, 16, 5, 1, 0xff2020, { solid: false, glow: true });
  door(16, 0, -2, 16.5, 4, 2, 0x5a5a60, { key: true });
  box(16, 0, -2.5, 21, 28.5, -2, SHAFT);
  box(16, 0, 2, 21, 28.5, 2.5, SHAFT);
  box(20.5, 0, -2, 21, 28.5, 2, SHAFT);
  box(16, 28, -2, 20.5, 28.5, 2, SHAFT);
  box(16.5, -1, -2, 20.5, -0.4, 2, SHAFT);
  box(16, 22, -2, 16.5, 24, 2, SHAFT);
  const liftMesh = box(16.5, -0.4, -2, 20.5, 0, 2, 0x707070, { solid: false });
  const lift = { box: { x0: 16.5, y0: -0.4, z0: -2, x1: 20.5, y1: 0, z1: 2 }, mesh: liftMesh, target: 24, moving: false };
  light(18.5, 14, 0, 0xff4020, 6, 14);

  // ── CUBICLE FLOOR: cramped, dim maze ──────────────────────────────────────────────────
  hall(-19.5, 8, -16.5, 12, 0, 3.5, CUBES, true);
  door(-18.25, 0, 8, -17.75, 3.5, 12, 0x7a6a50);
  room(-52, -16, -20, 24, 0, 3.5, CUBES, { e: [[8, 12, 3.5]], n: [[-40, -36, 3]], w: [[0, 3, 3.5]] });
  for (const z of [-10, -4, 2, 8, 14, 20]) {
    for (const [a, b] of [[-48, -38], [-35, -24]]) box(a, 0, z - 0.08, b, 1.9, z + 0.08, 0x5d6b78);
    for (const x of [-45, -41, -31, -27]) box(x - 0.08, 0, z - 1.4, x + 0.08, 1.9, z + 1.4, 0x5d6b78);
    for (const x of [-43, -29]) {
      const dz = z % 4 === 0 ? 0.55 : -0.55;
      box(x - 0.6, 0, z + dz - 0.35, x + 0.6, 0.75, z + dz + 0.35, 0x8b6f4e);
      box(x - 0.25, 0.75, z + dz - 0.08, x + 0.25, 1.15, z + dz + 0.08, 0x202428, { solid: false });
    }
  }
  for (const [x, z, f] of [[-26, 0, false], [-36, 10, true], [-46, -8, false], [-36, -12, false], [-44, 18, true]]) {
    box(x - 1, 3.45, z - 0.3, x + 1, 3.5, z + 0.3, 0xf0f8ff, { solid: false, glow: true });
    light(x, 3.2, z, 0xe0ffe8, 5, 11, f);
  }
  // The supply closet's wall is a slightly different beige (secret 3).
  door(-52.5, 0, 0, -52, 3.5, 3, 0xcdbf9a, { secret: true });
  room(-56, -0.5, -52.5, 3.5, 0, 3.5, VENT, { e: [[-0.5, 3.5, 3.5]] });
  trig(-56, 0, -0.5, -52.5, 3.5, 3.5, 'secret');
  pick('shells', -54.5, 0.4, 0.5);
  pick('shells', -54.5, 0.4, 2.5);
  pick('donut', -55.3, 0.4, 1.5);
  light(-54, 3, 1.5, 0xffe0a0, 2, 5);
  pick('shells', -22, 0.4, -14);
  pick('shells', -50, 0.4, 22);
  pick('shells', -36.5, 0.4, 0);
  pick('coffee', -29, 0.4, 17);
  pick('coffee', -43, 0.4, -6);
  pick('coffee', -50, 0.4, -14);
  pick('donut', -36.5, 0.4, 11);
  for (const [x, z] of [[-26, 16], [-30, 11], [-43, 17], [-47, 5], [-33, 5], [-26, -1], [-44, -7], [-36, -13], [-50, -12]]) mob('intern', x, 0, z);
  for (const [x, z] of [[-36.5, 18], [-46, 11], [-33, -7], [-41, -1], [-22, -12]]) mob('manager', x, 0, z);

  // ── SERVER ROOM: cold blue light, racks, hell bleeding in ─────────────────────────────
  hall(-40, -20.5, -36, -16.5, 0, 3, SERVER, false);
  door(-40, 0, -18.75, -36, 3, -18.25, 0x50606a);
  room(-52, -44, -24, -21, 0, 6, SERVER, { s: [[-40, -36, 3]], e: [[-38, -34, 4]] });
  for (const x of [-48, -44, -32, -28]) {
    box(x - 0.5, 0, -40, x + 0.5, 2.6, -25, 0x16191e);
    for (let y = 0.5; y < 2.4; y += 0.45) box(x - 0.52, y, -39.5, x + 0.52, y + 0.04, -25.5, y % 0.9 < 0.45 ? 0x20ff60 : 0x2080ff, { solid: false, glow: true });
  }
  box(-47, 0, -23.5, -45, 0.9, -22.5, 0x30363e); // launcher table
  box(-38.4, 0, -43, -37.6, 0.9, -42, 0x30363e); // keycard pedestal
  for (const [x, z] of [[-46, -32], [-30, -32], [-38, -30]]) light(x, 5, z, 0x3070ff, 10, 18);
  light(-38, 2, -42, 0xff2020, 4, 6);
  flesh(-38, 4, -43.8, 1.6);
  flesh(-51.8, 2, -42, 1.2);
  flesh(-24.2, 4.5, -36, 1.2);
  flesh(-30, 5.8, -40, 1);
  pick('launcher', -46, 1.3, -23);
  pick('key', -38, 1.3, -42.5);
  pick('toner', -30, 0.4, -42);
  pick('toner', -50, 0.4, -35);
  pick('shells', -36, 0.4, -24);
  pick('donut', -26, 0.4, -30);
  mob('intern', -46, 0, -30);
  mob('intern', -30, 0, -33);
  mob('manager', -38, 0, -35);
  mob('manager', -26, 0, -41);
  // Keycard ambush.
  mob('brute', -50, 0, -42, 'server');
  mob('brute', -26, 0, -23, 'server');
  mob('brute', -38, 0, -26, 'server');
  mob('printer', -44, 4, -42, 'server');
  mob('printer', -32, 4, -42, 'server');

  // ── RED CORRIDOR back to the lobby (the loop) ─────────────────────────────────────────
  box(-23.5, -0.5, -38, 2, 0, -34, HELL.floor);
  box(-23.5, 4, -38, 2, 4.5, -34, HELL.ceil);
  box(-23.5, 0, -38.5, 2.5, 4, -38, HELL.wall);
  box(-23.5, 0, -34, -2, 4, -33.5, HELL.wall);
  box(2, 0, -38, 2.5, 4, -16.5, HELL.wall);
  box(-2, -0.5, -34, 2, 0, -16.5, HELL.floor);
  box(-2, 4, -34, 2, 4.5, -16.5, HELL.ceil);
  box(-2.5, 0, -33.5, -2, 4, -16.5, HELL.wall);
  light(-12, 3.5, -36, 0xff3020, 5, 14);
  light(0, 3.5, -26, 0xff3020, 5, 14);
  flesh(-16, 3.8, -37.8, 1.2);
  flesh(1.8, 2, -30, 1);
  flesh(-6, 0.2, -34.2, 1);
  pick('shells', -20, 0.4, -36);
  pick('toner', -6, 0.4, -36);
  pick('coffee', 0, 0.4, -25);
  pick('coffee', 0, 0.4, -22);
  mob('intern', -15, 0, -36);
  mob('intern', 0, 0, -30);
  mob('brute', -8, 0, -36);

  // ── CEO FLOOR: open arena, everything at once, exit behind the desk ──────────────────
  room(-16, -16, 16, 16, 24, 32, CEO, { e: [[-2, 2, 4]], n: [[-2, 2, 4]] });
  box(-5, 24, -11, 5, 25.1, -9, 0x4a2a18); // CEO desk landmark
  box(-0.6, 24, -13, 0.6, 25.8, -12.2, 0x1a1010);
  for (const [x, z] of [[-9, -7], [9, -7], [-9, 7], [9, 7]]) box(x - 1, 24, z - 1, x + 1, 32, z + 1, 0x8a7a6a);
  box(-13, 24, 3, -11, 25.2, 5, 0x5a4030);
  box(11, 24, -4, 13, 25.2, -2, 0x5a4030);
  box(3, 24, 11, 5, 25.2, 13, 0x5a4030);
  for (const [x, z] of [[-8, -8], [8, -8], [-8, 8], [8, 8]]) light(x, 30, z, 0xff5030, 18, 30);
  light(0, 29, -12, 0xffd0a0, 10, 16);
  flesh(-15.8, 28, -10, 2);
  flesh(15.8, 29, 9, 2);
  flesh(0, 31.8, 0, 2.5);
  flesh(-9, 31.5, 7, 1.5);
  flesh(-6, 24, -15.6, 1.5);
  door(-2, 24, -16.5, 2, 28, -16, 0x30a040);
  hall(-2, -20, 2, -16.5, 24, 4, CEO, false);
  box(-2.5, 24, -20.5, 2.5, 28, -20, CEO.wall);
  box(-1.2, 28.3, -15.95, 1.2, 28.9, -15.9, 0x20ff40, { solid: false, glow: true });
  light(0, 27, -18, 0x40ff60, 4, 6);
  trig(-2, 24, -20, 2, 28, -17.5, 'exit');
  pick('shells', -14, 24.4, -14);
  pick('shells', 14, 24.4, 14);
  pick('toner', -14, 24.4, 14);
  pick('toner', 14, 24.4, -14);
  pick('donut', -12, 24.4, 0);
  pick('donut', 12, 24.4, 6);
  for (const [x, z] of [[-12, -12], [12, -12], [-12, 12]]) mob('intern', x, 24, z);
  for (const [x, z] of [[0, -6], [-6, 10], [6, 10]]) mob('manager', x, 24, z);
  mob('brute', -10, 24, 0);
  mob('brute', 12, 24, 10);
  mob('printer', 0, 28, 4);
  mob('printer', -4, 29, -4);

  return { solids, doors, lift, triggers, pickups, enemies, flicker, spawn: { pos: new THREE.Vector3(-7, 0, 13), yaw: Math.atan2(-7, 29) } };
}
