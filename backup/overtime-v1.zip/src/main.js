import * as THREE from 'three';
import { createWorld, updateWorld } from './world.js';
import { Viewmodel, EYE } from './player.js';
import { Audio } from './audio.js';
import { Hud } from './hud.js';

const canvas = document.getElementById('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.autoClear = false;
const camera = new THREE.PerspectiveCamera(90, 1, 0.05, 200);
camera.rotation.order = 'YXZ';
const viewmodel = new Viewmodel();
const audio = new Audio();
const hud = new Hud();

// Pixel filter: render at ~320x200, then upscale with nearest sampling and crush to a 6-level-per-channel palette.
const rt = new THREE.WebGLRenderTarget(320, 200, { minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
const postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
const post = new THREE.Scene();
post.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.ShaderMaterial({
  uniforms: { tex: { value: rt.texture }, res: { value: new THREE.Vector2(320, 200) } },
  vertexShader: 'varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
  fragmentShader: `
    uniform sampler2D tex; uniform vec2 res; varying vec2 vUv;
    float bayer(vec2 p) {
      int x = int(mod(p.x, 4.0)), y = int(mod(p.y, 4.0)), i = x + y * 4;
      int m[16] = int[16](0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5);
      return float(m[i]) / 16.0 - 0.5;
    }
    void main() {
      vec3 c = pow(texture2D(tex, vUv).rgb, vec3(1.0 / 2.2));
      c = floor(c * 5.0 + 0.5 + bayer(floor(vUv * res)) * 0.6) / 5.0;
      gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
    }`,
})));
let pixel = true;

function resize() {
  const w = innerWidth, h = innerHeight, aspect = w / h;
  renderer.setSize(w, h, false);
  camera.aspect = viewmodel.camera.aspect = aspect;
  camera.fov = THREE.MathUtils.radToDeg(2 * Math.atan(1 / aspect)); // 90° horizontal
  camera.updateProjectionMatrix();
  viewmodel.camera.updateProjectionMatrix();
  const rw = Math.round(200 * aspect);
  rt.setSize(rw, 200);
  post.children[0].material.uniforms.res.value.set(rw, 200);
}
addEventListener('resize', resize);
resize();

// ── state + input ─────────────────────────────────────────────────────────────────────
let state = 'title', game = null, deadT = 0;
const input = { keys: {}, fire: false, switchTo: null, cycle: 0 };
const locked = () => document.pointerLockElement === canvas;
const lock = () => canvas.requestPointerLock()?.catch?.(() => {});

function dispose(scene) {
  scene.traverse((o) => {
    o.geometry?.dispose();
    o.material?.dispose?.();
  });
}

function newGame() {
  if (game) dispose(game.scene);
  game = createWorld(audio, hud);
  if (import.meta.env.DEV) Object.assign(window, { game, input }); // console poking while developing
  state = 'playing';
  deadT = 0;
  input.fire = false;
  hud.screen(null);
  audio.resume();
}

function click() {
  if (state === 'title') {
    audio.init();
    newGame();
  } else if (state === 'dead' && deadT > 0.6) newGame();
  else if (state === 'score') newGame();
  if (!locked()) lock();
}

hud.screen('title');
document.getElementById('screen').addEventListener('click', click);
canvas.addEventListener('mousedown', (e) => {
  if (state === 'playing' && locked()) {
    if (e.button === 0) input.fire = true;
  } else click();
});
addEventListener('mouseup', (e) => { if (e.button === 0) input.fire = false; });
addEventListener('wheel', (e) => { if (state === 'playing') input.cycle = Math.sign(e.deltaY); }, { passive: true });
addEventListener('mousemove', (e) => {
  if (state !== 'playing' || !locked()) return;
  const p = game.player;
  p.yaw -= e.movementX * 0.0022;
  p.pitch = Math.max(-1.55, Math.min(1.55, p.pitch - e.movementY * 0.0022));
});
document.addEventListener('pointerlockchange', () => {
  if (!locked() && state === 'playing') {
    state = 'paused';
    input.fire = false;
    input.keys = {};
    audio.suspend();
    hud.screen('paused');
  } else if (locked() && state === 'paused') {
    state = 'playing';
    audio.resume();
    hud.screen(null);
  }
});
addEventListener('keydown', (e) => {
  if (e.code === 'Space') e.preventDefault();
  input.keys[e.code] = true;
  if (e.code === 'KeyP') pixel = !pixel;
  if (e.code === 'KeyR' && state !== 'title') {
    newGame();
    if (!locked()) lock();
  }
  const slot = { Digit1: 'axe', Digit2: 'shotgun', Digit3: 'launcher' }[e.code];
  if (slot) input.switchTo = slot;
});
addEventListener('keyup', (e) => { input.keys[e.code] = false; });
addEventListener('blur', () => { input.keys = {}; input.fire = false; });

// ── loop ──────────────────────────────────────────────────────────────────────────────
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  if (!game) return;
  if (state === 'playing') {
    updateWorld(game, input, dt);
    input.switchTo = null;
    input.cycle = 0;
    if (game.player.dead) state = 'dead';
    else if (game.exited) {
      state = 'score';
      document.exitPointerLock();
      hud.screen('score', game);
    }
  } else if (state === 'dead') {
    deadT += dt; // brief freeze, then offer the restart
    if (deadT > 0.6 && document.getElementById('screen').hidden) hud.screen('dead');
  }
  if (state === 'playing' || state === 'dead') hud.update(game, dt);
  render(dt);
}

function render(dt) {
  const p = game.player, s = game.shake;
  camera.position.set(p.pos.x + (Math.random() - 0.5) * s * 0.3, p.pos.y + (p.dead ? 0.3 : EYE) + (Math.random() - 0.5) * s * 0.3, p.pos.z);
  camera.rotation.set(p.pitch, p.yaw, p.dead ? 0.5 : 0);
  Object.assign(audio.listener, { x: camera.position.x, y: camera.position.y, z: camera.position.z, yaw: p.yaw });
  viewmodel.update(p, state === 'playing' ? dt : 0);
  renderer.setRenderTarget(pixel ? rt : null);
  renderer.clear();
  renderer.render(game.scene, camera);
  renderer.clearDepth();
  renderer.render(viewmodel.scene, viewmodel.camera);
  if (pixel) {
    renderer.setRenderTarget(null);
    renderer.clear();
    renderer.render(post, postCam);
  }
}
requestAnimationFrame(frame);
