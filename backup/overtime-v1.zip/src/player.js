import * as THREE from 'three';
import { moveBody, raycast, updateBox, boxDist } from './physics.js';
import { damageEnemy, spawnProjectile, hitscan, losClear, wakeNear } from './world.js';

// Quake-lite: 12 m/s run (~2.5x a modern walk), Quake air acceleration so strafe-jumping and bunny-hopping just work.
const MAX_SPEED = 12, ACCEL = 10, AIR_ACCEL = 12, AIR_CAP = 1.2, FRICTION = 5, STOP_SPEED = 3.5, JUMP = 9, G = 28;
export const EYE = 1.55;
export const WEAPONS = ['axe', 'shotgun', 'launcher'];
const COOLDOWN = { axe: 0.5, shotgun: 0.95, launcher: 0.8 };

const wish = new THREE.Vector3(), eye = new THREE.Vector3(), dir = new THREE.Vector3(), pd = new THREE.Vector3(), v = new THREE.Vector3();

export function createPlayer(spawn) {
  const p = {
    pos: spawn.pos.clone(), vel: new THREE.Vector3(), r: 0.4, h: 1.7, box: {}, yaw: spawn.yaw, pitch: 0, onGround: false,
    health: 100, armor: 0, dead: false, hasKey: false,
    owned: { axe: true, shotgun: true, launcher: false }, ammo: { shells: 24, toner: 0 },
    weapon: 'shotgun', cooldown: 0, switchT: 0, kick: 0, flash: 0, swing: 0, pumpT: 0,
  };
  updateBox(p);
  return p;
}

export const aim = (yaw, pitch, out) => out.set(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));

function accelerate(vel, wishSpeed, accel, dt, cap = wishSpeed) {
  const add = cap - (vel.x * wish.x + vel.z * wish.z);
  if (add <= 0) return;
  const a = Math.min(accel * dt * wishSpeed, add);
  vel.x += a * wish.x;
  vel.z += a * wish.z;
}

export function movePlayer(g, input, dt) {
  const p = g.player, k = input.keys;
  const f = (k.KeyW ? 1 : 0) - (k.KeyS ? 1 : 0), s = (k.KeyD ? 1 : 0) - (k.KeyA ? 1 : 0);
  const sin = Math.sin(p.yaw), cos = Math.cos(p.yaw);
  wish.set(-sin * f + cos * s, 0, -cos * f - sin * s);
  if (wish.lengthSq() > 0) wish.normalize();
  // Jumping before friction is what makes holding space bunny-hop.
  if (p.onGround && k.Space) {
    p.vel.y = JUMP;
    p.onGround = false;
  }
  if (p.onGround) {
    const speed = Math.hypot(p.vel.x, p.vel.z);
    if (speed > 0) {
      const scale = Math.max(0, speed - Math.max(speed, STOP_SPEED) * FRICTION * dt) / speed;
      p.vel.x *= scale;
      p.vel.z *= scale;
    }
    accelerate(p.vel, MAX_SPEED, ACCEL, dt);
  } else accelerate(p.vel, MAX_SPEED, AIR_ACCEL, dt, AIR_CAP);
  p.vel.y -= G * dt;
  const hit = moveBody(p, p.vel.x * dt, p.vel.y * dt, p.vel.z * dt, g.solids);
  if (hit.x) p.vel.x = 0;
  if (hit.z) p.vel.z = 0;
  p.onGround = hit.y && p.vel.y < 0;
  if (hit.y) p.vel.y = 0;
}

function bestWeapon(p) {
  return p.ammo.shells > 0 ? 'shotgun' : p.owned.launcher && p.ammo.toner > 0 ? 'launcher' : 'axe';
}

export function selectWeapon(p, w) {
  if (!p.owned[w] || p.weapon === w) return;
  p.weapon = w;
  p.switchT = 0.25;
}

export function updateWeapons(g, input, dt) {
  const p = g.player;
  if (input.switchTo) selectWeapon(p, input.switchTo);
  if (input.cycle) {
    const owned = WEAPONS.filter((w) => p.owned[w]);
    selectWeapon(p, owned[(owned.indexOf(p.weapon) + input.cycle + owned.length) % owned.length]);
  }
  p.cooldown -= dt;
  p.switchT = Math.max(0, p.switchT - dt);
  p.kick = Math.max(0, p.kick - dt * 5);
  p.flash -= dt;
  p.swing = Math.max(0, p.swing - dt / 0.35);
  p.pumpT -= dt;
  if (input.fire && p.cooldown <= 0 && p.switchT <= 0) fire(g);
}

function fire(g) {
  const p = g.player, w = p.weapon;
  eye.set(p.pos.x, p.pos.y + EYE, p.pos.z);
  aim(p.yaw, p.pitch, dir);
  if ((w === 'shotgun' && p.ammo.shells <= 0) || (w === 'launcher' && p.ammo.toner <= 0)) {
    g.audio.play('dry');
    p.cooldown = 0.3;
    selectWeapon(p, bestWeapon(p));
    return;
  }
  p.cooldown = COOLDOWN[w];

  if (w === 'axe') {
    p.swing = 1;
    g.audio.play('axe');
    let best = null, bestD = 2.4;
    for (const e of g.enemies) {
      if (e.dead || !e.active) continue;
      const d = boxDist(eye, e.box);
      if (d >= bestD) continue;
      v.set(e.pos.x - eye.x, e.pos.y + e.h / 2 - eye.y, e.pos.z - eye.z).normalize();
      if ((v.dot(dir) < 0.5 && d > 0.3) || !losClear(g, eye, v.set(e.pos.x, e.pos.y + e.h / 2, e.pos.z))) continue;
      best = e;
      bestD = d;
    }
    if (best) {
      g.audio.play('axehit');
      damageEnemy(g, best, 60, 'player', 'axe');
      g.shake += 0.15;
    }
    return;
  }

  p.kick = 1;
  p.flash = 0.06;
  wakeNear(g, eye, 30); // gunfire wakes nearby rooms
  if (w === 'shotgun') {
    p.ammo.shells--;
    p.pumpT = 0.6;
    g.audio.play('shotgun');
    g.audio.play('pump', null, 0.38);
    const hits = new Map();
    for (let i = 0; i < 7; i++) {
      aim(p.yaw + (Math.random() - 0.5) * 0.14, p.pitch + (Math.random() - 0.5) * 0.09, pd);
      const h = hitscan(g, eye, pd, 80);
      if (h.enemy) hits.set(h.enemy, (hits.get(h.enemy) || 0) + 12);
      else g.fx.burst(v.copy(eye).addScaledVector(pd, h.t - 0.05), 0x8a8a80, 3, 2, 0.05, 0.3);
    }
    for (const [e, dmg] of hits) damageEnemy(g, e, dmg, 'player', 'shotgun');
    g.shake += 0.12;
  } else {
    p.ammo.toner--;
    g.audio.play('launcher');
    const t = raycast(g.solids, eye, dir, 0.6);
    v.copy(eye).addScaledVector(dir, Math.max(0, t - 0.1));
    spawnProjectile(g, 'toner', v, dir.clone().multiplyScalar(26).add(new THREE.Vector3(0, 2.5, 0)), 'player');
    g.shake += 0.08;
  }
}

// First-person weapon models, rendered in their own scene on top of the world.
export class Viewmodel {
  constructor() {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(70, 1, 0.01, 10);
    this.scene.add(new THREE.HemisphereLight(0xfff4e0, 0x403028, 3));
    const sun = new THREE.DirectionalLight(0xffffff, 1.5);
    sun.position.set(1, 2, 1);
    this.scene.add(sun);
    this.light = new THREE.PointLight(0xffc060, 0, 4, 1);
    this.light.position.set(0.3, 0, -0.9);
    this.scene.add(this.light);
    const cube = new THREE.BoxGeometry(1, 1, 1);
    const part = (parent, w, h, d, color, x, y, z, glow = false) => {
      const m = new THREE.Mesh(cube, new THREE.MeshLambertMaterial({ color, emissive: glow ? color : 0 }));
      m.scale.set(w, h, d);
      m.position.set(x, y, z);
      parent.add(m);
      return m;
    };
    const gun = (x, y, z) => {
      const grp = new THREE.Group();
      grp.userData.base = new THREE.Vector3(x, y, z);
      this.scene.add(grp);
      return grp;
    };
    const axe = gun(0.42, -0.42, -0.65);
    part(axe, 0.06, 0.9, 0.06, 0x6a4020, 0, 0.15, 0);
    part(axe, 0.07, 0.22, 0.3, 0xc01010, 0, 0.55, -0.1);
    part(axe, 0.05, 0.26, 0.06, 0xd0d0d8, 0, 0.55, -0.27);
    const shotgun = gun(0.26, -0.28, -0.5);
    part(shotgun, 0.07, 0.07, 0.9, 0x222226, 0, 0.03, -0.3);
    part(shotgun, 0.06, 0.06, 0.7, 0x2a2a2e, 0, -0.04, -0.25);
    this.pump = part(shotgun, 0.1, 0.1, 0.28, 0x6a4020, 0, -0.04, -0.45);
    part(shotgun, 0.1, 0.14, 0.3, 0x1a1a1e, 0, 0, 0.1);
    part(shotgun, 0.08, 0.16, 0.4, 0x5a3418, 0, -0.06, 0.38);
    const launcher = gun(0.3, -0.3, -0.55);
    part(launcher, 0.22, 0.2, 0.6, 0xd8d0b8, 0, 0, -0.1);
    part(launcher, 0.14, 0.14, 0.25, 0x202020, 0, 0.02, -0.5);
    part(launcher, 0.23, 0.04, 0.3, 0xc01880, 0, 0.09, -0.1);
    part(launcher, 0.07, 0.18, 0.1, 0x303030, 0, -0.17, 0.05);
    this.guns = { axe, shotgun, launcher };
    this.muzzle = part(this.scene, 0.18, 0.18, 0.05, 0xffd060, 0.26, -0.25, -1.0, true);
    this.bob = 0;
  }

  update(p, dt) {
    const speed = Math.hypot(p.vel.x, p.vel.z);
    if (p.onGround) this.bob += dt * speed * 0.9;
    const amp = p.onGround ? Math.min(1, speed / 12) * 0.025 : 0;
    for (const [name, grp] of Object.entries(this.guns)) {
      grp.visible = name === p.weapon && !p.dead;
      if (!grp.visible) continue;
      const b = grp.userData.base;
      grp.position.set(b.x + Math.cos(this.bob) * amp, b.y - Math.abs(Math.sin(this.bob)) * amp - p.switchT * 1.2 - (p.dead ? 1 : 0), b.z + p.kick * 0.12);
      grp.rotation.set(p.kick * 0.25, 0, 0);
      if (name === 'axe') {
        const s = Math.sin((1 - p.swing) * Math.PI) * (p.swing > 0 ? 1 : 0);
        grp.rotation.set(-s * 1.5, s * 0.4, -0.3 + s * 0.3);
        grp.position.x -= s * 0.25;
      }
    }
    this.pump.position.z = -0.45 + (p.pumpT > 0 && p.pumpT < 0.3 ? Math.sin((p.pumpT / 0.3) * Math.PI) * 0.15 : 0);
    this.muzzle.visible = p.flash > 0 && p.weapon === 'shotgun';
    this.light.intensity = p.flash > 0 ? 8 : 0;
  }
}
