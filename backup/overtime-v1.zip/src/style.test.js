import assert from 'node:assert/strict';
import { createStyle, styleKill, styleHurt, styleDecay, rankOf, grade } from './style.js';

const s = createStyle();
assert.deepEqual(styleKill(s, 'shotgun', false, 0), []);
assert.equal(s.points, 30);
styleKill(s, 'shotgun', false, 5); // repeat weapon: diminishing
assert.equal(Math.round(s.points), 51);
const b = styleKill(s, 'axe', true, 5.5); // different weapon, axe, airborne, multi-kill
assert.deepEqual(b, ['VARIETY', 'HANDS-ON', 'AIRBORNE', 'MULTI-KILL']);
assert.equal(Math.round(s.points), 206);
assert.equal(rankOf(s), 2);
assert.deepEqual(styleKill(s, 'infight', false, 20), ['SYNERGY']);
styleHurt(s, 20);
assert.equal(rankOf(s), 2);
styleDecay(s, 1000);
assert.equal(s.points, 0);
assert.equal(s.peak, 2);

assert.equal(grade({ kills: 43, total: 43, secrets: 3, time: 200, peak: 5 }), 'S');
assert.equal(grade({ kills: 0, total: 43, secrets: 0, time: 900, peak: 0 }), 'F');
assert.equal(grade({ kills: 30, total: 43, secrets: 1, time: 300, peak: 3 }), 'C');
console.log('style ok');
