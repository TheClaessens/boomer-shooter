import * as THREE from 'three';
import { buildLevel } from './level.js';
import { moveBody, raycast, rayBox, boxDist } from './physics.js';
import { createPlayer, movePlayer, updateWeapons, selectWeapon, EYE } from './player.js';
import { spawnEnemy, updateEnemy, wake } from './enemies.js';
import { FX } from './fx.js';
import { createStyle, styleKill, styleDecay, styleHurt, rankOf, RANKS, MANAGER, VP } from './style.js';

const v1 = new THREE.Vector3(), v2 = new THREE.Vector3(), down = new THREE.Vector3(0, -1, 0);
const cube = new THREE.BoxGeometry(1, 1, 1);

export function createWorld(audio, hud) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x050404);
  scene.fog = new THREE.Fog(0x050404, 30, 100);
  scene.add(new THREE.AmbientLight(0xffffff, 0.25));
  const L = buildLevel(scene);
  const muzzle = new THREE.PointLight(0xffc070, 0, 16, 1);
  const boom = new THREE.PointLight(0xff8030, 0, 18, 1);
  scene.add(muzzle, boom);
  const g = {
    scene, audio, hud, time: 0,
    solids: [...L.solids, ...L.doors.map((d) => d.box), L.lift.box],
    doors: L.doors, lift: L.lift, triggers: L.triggers, flicker: L.flicker,
    enemies: [], pickups: [], projectiles: [], fx: new FX(scene),
    style: createStyle(), rank: 0, stats: { kills: 0, total: 0, secrets: 0, time: 0 },
    player: createPlayer(L.spawn), muzzle, boom, shake: 0, exited: false, sightCD: 0, lockedT: 0,
  };
  for (const [type, x, y, z, group] of L.enemies) g.enemies.push(spawnEnemy(g, type, x, y, z, group));
  g.stats.total = g.enemies.length;
  for (const [kind, x, y, z] of L.pickups) addPickup(g, kind, x, y, z);
  audio.setRank(0);
  return g;
}

export function updateWorld(g, input, dt) {
  const p = g.player;
  g.time += dt;
  g.stats.time += dt;
  g.sightCD -= dt;
  g.lockedT -= dt;
  updateDoors(g, dt);
  updateLift(g, dt);
  movePlayer(g, input, dt);
  updateWeapons(g, input, dt);
  for (const e of g.enemies) updateEnemy(g, e, dt);
  separate(g);
  updateProjectiles(g, dt);
  updatePickups(g, dt);
  updateTriggers(g);

  styleDecay(g.style, dt);
  const r = rankOf(g.style);
  if (r !== g.rank) {
    if (r > g.rank) {
      g.audio.play('rankup');
      g.hud.rankUp(RANKS[r]);
    } else g.audio.play('rankdown');
    g.rank = r;
    g.audio.setRank(r);
  }

  g.fx.update(dt, g.solids);
  g.muzzle.position.set(p.pos.x, p.pos.y + EYE, p.pos.z);
  g.muzzle.intensity = p.flash > 0 ? 25 : 0;
  g.boom.intensity = Math.max(0, g.boom.intensity - dt * 80);
  for (const f of g.flicker) f.light.intensity = Math.random() < 0.05 ? f.base * 0.1 : f.base;
  g.shake = Math.max(0, g.shake - dt * 2);
}

// ── combat ────────────────────────────────────────────────────────────────────────────

export function hitscan(g, o, d, maxT, ignore = null) {
  let t = raycast(g.solids, o, d, maxT), enemy = null;
  for (const e of g.enemies) {
    if (e.dead || !e.active || e === ignore) continue;
    const te = rayBox(o, d, e.box, t);
    if (te < t) { t = te; enemy = e; }
  }
  return { t, enemy };
}

export function losClear(g, a, b) {
  const d = v2.subVectors(b, a), len = d.length();
  if (len < 0.01) return true;
  d.divideScalar(len);
  return raycast(g.solids, a, d, len) >= len - 0.05;
}

export function wakeNear(g, pos, radius) {
  for (const e of g.enemies) if (e.active && !e.dead && e.state === 'sleep' && e.pos.distanceTo(pos) < radius) wake(g, e);
}

export function hurtPlayer(g, dmg, from) {
  const p = g.player;
  if (p.dead) return;
  const absorbed = Math.min(p.armor, dmg / 3); // armor soaks a third
  p.armor -= absorbed;
  p.health -= dmg - absorbed;
  styleHurt(g.style, dmg);
  g.shake += Math.min(0.5, dmg * 0.015);
  const dx = from.x - p.pos.x, dz = from.z - p.pos.z;
  const fwd = -dx * Math.sin(p.yaw) - dz * Math.cos(p.yaw), right = dx * Math.cos(p.yaw) - dz * Math.sin(p.yaw);
  g.hud.hurt(Math.atan2(right, fwd), dmg);
  if (p.health <= 0) {
    p.health = 0;
    p.dead = true;
    g.audio.play('death');
  } else g.audio.play('hurt');
}

// src: 'player' or the enemy that did it (which sets off infighting).
export function damageEnemy(g, e, dmg, src, weapon = null, opts = {}) {
  if (e.dead || !e.active) return;
  e.hp -= dmg;
  e.flash = 0.08;
  g.fx.burst(v1.set(e.pos.x, e.pos.y + e.h * 0.6, e.pos.z), e.def.blood, Math.min(24, 4 + dmg / 4), 4);
  if (src === 'player') e.target = null;
  else if (src !== e && !src.dead) e.target = src;
  if (e.state === 'sleep') wake(g, e);
  if (e.hp <= 0) return killEnemy(g, e, src, weapon, opts);
  if (Math.random() < e.def.pain && e.chargeT <= 0) {
    e.painT = 0.25;
    e.tellT = 0;
    g.audio.play('pain_' + e.type, e.pos);
  }
}

function killEnemy(g, e, src, weapon, opts) {
  const p = g.player;
  e.dead = true;
  g.stats.kills++;
  const pos = v1.set(e.pos.x, e.pos.y + e.h * 0.5, e.pos.z).clone();
  if (e.def.fly || e.hp < -15 - e.def.hp * 0.4 || (opts.explosive && e.hp < -10)) {
    e.root.visible = false;
    g.fx.gibs(pos, [e.def.blood, e.def.body, 0xa02838]);
    g.audio.play('gib', e.pos);
    g.shake += 0.1;
  } else g.audio.play('die_' + e.type, e.pos);
  for (const m of e.mats) m.emissive.setHex(0);
  const w = src === 'player' ? weapon : 'infight';
  g.hud.bonus(styleKill(g.style, w, !p.onGround, g.time));
  g.hud.grin();
  // The twist: style rank keeps you alive.
  const rank = rankOf(g.style);
  const floor = pos.y - raycast(g.solids, pos, down, 40);
  if (rank >= MANAGER) addPickup(g, 'mint', pos.x - 0.3, floor + 0.35, pos.z);
  if (rank >= VP) addPickup(g, 'shard', pos.x + 0.3, floor + 0.35, pos.z);
}

const PROJ = {
  toner: { dmg: 100, splash: 4, gravity: 14, radius: 0.15, parts: [[0.18, 0.18, 0.4, 0x151515], [0.2, 0.06, 0.2, 0xc01880]] },
  stapler: { dmg: 12, splash: 0, gravity: 0, radius: 0.25, parts: [[0.15, 0.12, 0.35, 0xff6010, true], [0.3, 0.3, 0.3, 0xff3000, true]] },
  ink: { dmg: 14, splash: 2.3, gravity: 3, radius: 0.3, parts: [[0.45, 0.45, 0.45, 0x281048, true]] },
};

export function spawnProjectile(g, kind, pos, vel, owner) {
  const P = PROJ[kind], mesh = new THREE.Group();
  for (const [w, h, d, color, glow] of P.parts) {
    const m = new THREE.Mesh(cube, new THREE.MeshLambertMaterial({ color, emissive: glow ? color : 0, transparent: kind === 'stapler' && w > 0.2, opacity: 0.5 }));
    m.scale.set(w, h, d);
    mesh.add(m);
  }
  mesh.position.copy(pos);
  g.scene.add(mesh);
  g.projectiles.push({ kind, ...P, pos: pos.clone(), vel, owner, life: 6, mesh });
}

function updateProjectiles(g, dt) {
  const p = g.player;
  for (let i = g.projectiles.length - 1; i >= 0; i--) {
    const pr = g.projectiles[i];
    pr.vel.y -= pr.gravity * dt;
    pr.life -= dt;
    const len = pr.vel.length() * dt;
    const d = v2.copy(pr.vel).normalize();
    let t = raycast(g.solids, pr.pos, d, len), body = null;
    const bodies = pr.owner === 'player' ? g.enemies : [p, ...g.enemies];
    for (const b of bodies) {
      if (b === pr.owner || b.dead || b.active === false) continue;
      const bx = b.box, r = pr.radius;
      const tb = rayBox(pr.pos, d, { x0: bx.x0 - r, y0: bx.y0 - r, z0: bx.z0 - r, x1: bx.x1 + r, y1: bx.y1 + r, z1: bx.z1 + r }, t);
      if (tb < t) { t = tb; body = b; }
    }
    pr.mesh.lookAt(v1.copy(pr.pos).add(d));
    if (t >= len && pr.life > 0) {
      pr.pos.addScaledVector(d, len);
      pr.mesh.position.copy(pr.pos);
      if (pr.kind === 'stapler' && Math.random() < 0.5) g.fx.burst(pr.pos, 0xff8020, 1, 0.5, 0.06, 0.2);
      continue;
    }
    pr.pos.addScaledVector(d, Math.max(0, t - 0.1));
    g.scene.remove(pr.mesh);
    g.projectiles.splice(i, 1);
    if (pr.splash) explode(g, pr);
    else if (body === p) hurtPlayer(g, pr.dmg, pr.pos);
    else if (body) damageEnemy(g, body, pr.dmg, pr.owner);
    else {
      g.fx.burst(pr.pos, 0xff8020, 6, 3, 0.06, 0.3);
      g.audio.play('splat', pr.pos);
    }
  }
}

function explode(g, pr) {
  const p = g.player, R = pr.splash, toner = pr.kind === 'toner';
  g.fx.explosion(pr.pos, R * 0.8, toner ? 0xff8a20 : 0x401870);
  g.audio.play(toner ? 'explode' : 'ink', pr.pos);
  if (toner) {
    g.boom.position.copy(pr.pos);
    g.boom.intensity = 40;
    g.shake += Math.max(0, 0.6 - pr.pos.distanceTo(p.pos) * 0.03);
    wakeNear(g, pr.pos, 25);
  }
  for (const b of [p, ...g.enemies]) {
    // Printers shrug off their own ink; the player's toner still hurts the player (owner is 'player', not a body).
    if (b.dead || b.active === false || b === pr.owner) continue;
    const dist = boxDist(pr.pos, b.box);
    if (dist >= R || !losClear(g, pr.pos, v1.set(b.pos.x, b.pos.y + b.h * 0.5, b.pos.z))) continue;
    const k = 1 - dist / R;
    if (b === p) {
      // Rocket jump: shove away from the blast, costs a third of the damage.
      const kb = v1.set(p.pos.x, p.pos.y + p.h * 0.5, p.pos.z).sub(pr.pos).normalize().multiplyScalar((toner ? 22 : 6) * k);
      p.vel.add(kb);
      hurtPlayer(g, pr.dmg * k * (pr.owner === 'player' ? 0.35 : 1), pr.pos);
    } else damageEnemy(g, b, pr.dmg * k, pr.owner, 'launcher', { explosive: toner });
  }
}

// Bodies push each other apart so crowds don't stack.
function separate(g) {
  const list = [g.player, ...g.enemies.filter((e) => e.active && !e.dead)];
  for (let i = 0; i < list.length; i++) {
    for (let j = i + 1; j < list.length; j++) {
      const a = list[i], b = list[j];
      if (a.dead || a.box.y1 <= b.box.y0 || b.box.y1 <= a.box.y0) continue;
      const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z, min = a.r + b.r, d = Math.hypot(dx, dz);
      if (d >= min) continue;
      const push = (min - d) / 2, nx = d > 0.01 ? dx / d : 1, nz = d > 0.01 ? dz / d : 0;
      moveBody(a, -nx * push, 0, -nz * push, g.solids);
      moveBody(b, nx * push, 0, nz * push, g.solids);
    }
  }
}

// ── pickups ───────────────────────────────────────────────────────────────────────────

const LOOK = {
  coffee: [[0.22, 0.3, 0.22, 0xf0ece0], [0.24, 0.05, 0.24, 0x5a3010, 0, 0.17]],
  donut: [[0.6, 0.15, 0.45, 0xf080b0], [0.5, 0.02, 0.35, 0xffffff, 0, 0.08]],
  espresso: [[0.3, 0.3, 0.3, 0xffd040], [0.36, 0.06, 0.36, 0x3a1a08, 0, 0.18]],
  kevlar: [[0.6, 0.7, 0.25, 0x2050c0], [0.62, 0.1, 0.27, 0x101830, 0, 0.1]],
  shard: [[0.18, 0.3, 0.18, 0x40a0ff]],
  mint: [[0.2, 0.2, 0.2, 0x40ff80]],
  shells: [[0.45, 0.25, 0.28, 0xb01818], [0.46, 0.06, 0.29, 0xd0a020, 0, -0.08]],
  toner: [[0.45, 0.25, 0.25, 0x151515], [0.46, 0.08, 0.26, 0xc01880]],
  launcher: [[0.25, 0.22, 0.7, 0xd8d0b8], [0.26, 0.05, 0.3, 0xc01880, 0, 0.1]],
  key: [[0.4, 0.26, 0.04, 0xff1010], [0.15, 0.15, 0.05, 0xffffff, -0.08, 0]],
};

export function addPickup(g, kind, x, y, z) {
  const mesh = new THREE.Group();
  for (const [w, h, d, color, ox = 0, oy = 0] of LOOK[kind]) {
    const m = new THREE.Mesh(cube, new THREE.MeshLambertMaterial({ color, emissive: color, emissiveIntensity: 0.35 }));
    m.scale.set(w, h, d);
    m.position.set(ox, oy, 0);
    mesh.add(m);
  }
  mesh.position.set(x, y, z);
  g.scene.add(mesh);
  g.pickups.push({ kind, x, y, z, mesh, phase: Math.random() * 6 });
}

const heal = (p, n, max) => p.health < max && (p.health = Math.min(max, p.health + n), true);
const armor = (p, n) => p.armor < 100 && (p.armor = Math.min(100, p.armor + n), true);
const ammo = (p, type, n, max) => p.ammo[type] < max && (p.ammo[type] = Math.min(max, p.ammo[type] + n), true);

function take(g, kind) {
  const p = g.player;
  switch (kind) {
    case 'coffee': return heal(p, 10, 100) && 'COFFEE +10';
    case 'donut': return heal(p, 25, 100) && 'DONUT BOX +25';
    case 'espresso': return heal(p, 100, 200) && 'ESPRESSO! +100';
    case 'mint': return heal(p, 5, 100) && 'BREATH MINT +5';
    case 'kevlar': return armor(p, 50) && 'KEVLAR VEST';
    case 'shard': return armor(p, 5) && 'ARMOR SHARD';
    case 'shells': return ammo(p, 'shells', 8, 50) && 'SHELLS';
    case 'toner': return ammo(p, 'toner', 4, 20) && 'TONER PACK';
    case 'launcher':
      p.owned.launcher = true;
      p.ammo.toner = Math.min(20, p.ammo.toner + 10);
      selectWeapon(p, 'launcher');
      return 'TONER LAUNCHER! [3]';
    case 'key':
      p.hasKey = true;
      ambush(g, 'server');
      return 'RED KEYCARD';
  }
}

function updatePickups(g, dt) {
  const p = g.player;
  for (let i = g.pickups.length - 1; i >= 0; i--) {
    const pu = g.pickups[i];
    pu.phase += dt * 3;
    pu.mesh.rotation.y = pu.phase * 0.7;
    pu.mesh.position.y = pu.y + Math.sin(pu.phase) * 0.08;
    if (p.dead || Math.hypot(p.pos.x - pu.x, p.pos.z - pu.z) > 1.2 || pu.y < p.pos.y - 0.5 || pu.y > p.pos.y + p.h + 0.5) continue;
    const label = take(g, pu.kind);
    if (!label) continue;
    g.scene.remove(pu.mesh);
    g.pickups.splice(i, 1);
    g.audio.play(pu.kind === 'launcher' ? 'weapon' : pu.kind === 'key' ? 'key' : 'pickup');
    g.hud.msg(label, 1.5);
    g.hud.pickupFlash();
  }
}

// ── doors, lift, triggers ─────────────────────────────────────────────────────────────

function updateDoors(g, dt) {
  const p = g.player;
  for (const d of g.doors) {
    const near = Math.hypot(p.pos.x - d.cx, p.pos.z - d.cz) < (d.secret ? 1.4 : 3.5) && p.pos.y > d.base.y0 - 1 && p.pos.y < d.base.y1;
    let want = near && (!d.key || p.hasKey);
    if (near && d.key && !p.hasKey && g.lockedT <= 0) {
      g.hud.msg('RED KEYCARD REQUIRED', 2);
      g.audio.play('locked');
      g.lockedT = 2;
    }
    if (!want && !d.key && !d.secret) want = g.enemies.some((e) => e.active && !e.dead && e.state !== 'sleep' && Math.hypot(e.pos.x - d.cx, e.pos.z - d.cz) < 2.5);
    const blocked = [p, ...g.enemies].some((b) => !b.dead && b.box.x1 > d.base.x0 && b.box.x0 < d.base.x1 && b.box.z1 > d.base.z0 && b.box.z0 < d.base.z1 && b.box.y1 > d.base.y0 && b.box.y0 < d.base.y1);
    if (want || blocked) d.hold = 2;
    else d.hold -= dt;
    const target = d.hold > 0 ? 1 : 0;
    if (target && d.open === 0) g.audio.play('door', v1.set(d.cx, d.base.y0 + 1, d.cz));
    d.open = target ? Math.min(1, d.open + dt * 4) : Math.max(0, d.open - dt * 1.5);
    const off = d.open * d.h * 0.95;
    d.box.y0 = d.base.y0 + off;
    d.box.y1 = d.base.y1 + off;
    for (const m of d.meshes) m.position.y = m.userData.baseY + off;
  }
}

function updateLift(g, dt) {
  const L = g.lift, p = g.player, b = L.box;
  const riding = p.onGround && Math.abs(p.pos.y - b.y1) < 0.05 && p.pos.x > b.x0 && p.pos.x < b.x1 && p.pos.z > b.z0 && p.pos.z < b.z1;
  if (riding && !L.moving && b.y1 < L.target) {
    L.moving = true;
    g.audio.play('lift');
  }
  if (!L.moving || b.y1 >= L.target) return;
  const dy = Math.min(4 * dt, L.target - b.y1);
  b.y0 += dy;
  b.y1 += dy;
  L.mesh.position.y += dy;
  if (riding || (p.pos.y < b.y1 && p.pos.y > b.y0 - p.h && p.pos.x > b.x0 && p.pos.x < b.x1 && p.pos.z > b.z0 && p.pos.z < b.z1)) p.pos.y = b.y1 + 0.001;
}

function ambush(g, group) {
  for (const e of g.enemies) {
    if (e.group !== group || e.active) continue;
    e.active = true;
    e.root.visible = true;
    wake(g, e);
    g.fx.burst(v1.set(e.pos.x, e.pos.y + e.h / 2, e.pos.z), 0xff2040, 20, 6, 0.12, 0.7);
    g.audio.play('spawn', e.pos);
  }
}

function updateTriggers(g) {
  const p = g.player, x = p.pos.x, y = p.pos.y + 0.5, z = p.pos.z;
  for (const t of g.triggers) {
    const b = t.box;
    if (t.fired || x < b.x0 || x > b.x1 || y < b.y0 || y > b.y1 || z < b.z0 || z > b.z1) continue;
    if (t.kind === 'ambush' && !p.hasKey) continue;
    t.fired = true;
    if (t.kind === 'secret') {
      g.stats.secrets++;
      g.audio.play('secret');
      g.hud.msg(`SECRET FOUND! ${g.stats.secrets}/3`, 3);
    } else if (t.kind === 'ambush') ambush(g, t.arg);
    else if (t.kind === 'exit') g.exited = true;
  }
}
